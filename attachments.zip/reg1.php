

<html>
<head>
<title>NewRegister
</title>
<link rel="stylesheet" type="text/css" href="style.css">

</head>
	<body>
<table width="100%" border="3" align="center" bordercolor="yellow">
<div class="menu">
 
 <div class="leftmenu">
 <h8>PLACEMENT&nbsp;CELL</h8>
 </div>
 </table>
 <div class="rightmenu">
 <ul>
 <li><a href="intent.php">Home</a></li>
 <li><a href="studentlogin.php">Student</a></li>
 </ul>
 </div>
</div> 
<HR>
<form method="post" action="regprocess.php">
	<table align="center" margin="0px" padding="0px">
	<tbody>
		<tr>
<th><font size="22" color="red">
<h4>Registration</h4></font>
	</th>
	</tr>	
	<tr>
<th>Name:</th>
<td><input type="text" name="name"></td>
<br><br>
	</tr>
	<tr>
<th>D.No:</th>
<td><input type="text" name="dno"></td>
<br><br>
	</tr>
	<tr>
<th>Date of Birth:</th>
<td><input type="date" name="dob"></td>
<br><br>
	</tr>
	<tr>
<th>Phone Number:</th>
<td><input type="number" name="phone"></td>
<br><br>
	</tr>
	<tr>
<th>E-Mail:</th>
<td><input type="text" name="email" placeholder="Example@gmai.com"></td>
<br><br>
	</tr>
	<tr>
<th>Gender:</th>
<td> <input type="radio" name="gender">Male<input type="radio" name="gender"s>Female</td>
<br><br>
	</tr>
	<tr>
<th>Class:</th>
<td><select size="1" name="class">
<option value="3UG">3 UG</option>
<option value="2PG">2 PG</option>
</select></td>
	<br><br>
</tr>
<tr>
<th>Department:</th>
<td><select size="1" name="department" id="department">
<option value="1">BIO-CHEMISTRY</option>
<option value="2">BOTANY</option>
<option value="3">BIO-TECHNOLOGY</option>
<option value="4">BUSINESS ADMINISTRATION</option>
<option value="6">COMPUTER SCIENCE AND APPLICATIONS</option>
<option value="7">CHEMISTRY</option>
<option value="8">COMMERCE</option>
<option value="9">COMPUTER SCIENCE</option>
<option value="10">INFORMATION TECHNOLOGY</option>
<option value="11">ECONOMICS</option>
<option value="12">ELECTRONICS</option>
<option value="13">ENGLISH</option>
<option value="14">HUMAN EXCELLENCE</option>
<option value="15">MATHEMATICS</option>
<option value="16">PHYSICS</option>
<option value="17">STATISTICS</option>
<option value="17">SOFTWARE DEVELOPMENT</option>
<option value="18">COMMERCE COMPUTER APPLICATIONS</option>
</select>
</td>
</tr>
<br>
<br>
<tr>
<br><th><input type="submit" name="submit" value="Register"></th>&emsp;<td><input type="reset" name="reset"></td>
</tr>
</tbody>
</table>
</form>
<br>
<br>
</body>
</html>
