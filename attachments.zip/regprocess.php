<?php
	$con =  mysqli_connect('localhost','root','');
	if(!$con)
	{
		echo 'NOT Connected to Server';
	}
	if(mysqli_select_db($con,'project'))
	{
		echo 'Database Not Selected';
	}

	$D_NO  = $_POST["dno"];
	$Name = $_POST['name'];
	$D_O_B = $_POST['dob'];
	$department = $_POST['department'];
	$class = $_POST['class'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];

	$sql = "INSERT INTO student values('$D_NO','$Name','$D_O_B','$department','$class','$phone','$email')";
	
	if(!mysqli_query($con,$sql))
	{
		echo 'Some values missing';
	}
	else
	{
		echo 'sucessfully completed';
	}
	header("refresh:2; url=reg1.php");
	?>
