<html>
<head>
<title>sjcplacement
</title>

<link rel="stylesheet" type="text/css" href="style.css">

</head><body>
<table width="100%" border="3" align="center" bordercolor="yellow">
<div class="menu">
 
 <div class="leftmenu">
 <h8>PLACEMENT&nbsp;CELL</h8>
 </div>
 </table> 
 <div class="rightmenu">
 <ul>
 <li><a href="liststud.php">Student List</a></li>
 <li><a href="annoce.php">Announcement</a></li>
  <li><a href="adminlogin.php">Logout</a></li>
  </ul>
 </div>
</div> 

 <form method="post" name="f3" action="anoprocess.php">
  <table width="100%" border="0" align="center">
    <tr>
            <td width="8%" height="48">&nbsp;</td>
            <td width="9%"><span><b>S_NO </b></span></td>
            <td width="23%"><label>
              <input name="sno" type="number" id="sno" placeholder="enter the number">
            </label></td>
            <td width="23%">&nbsp;</td>
            <td width="8%">&nbsp;</td>
          </tr>
    <tr>
            <td width="8%" height="48">&nbsp;</td>
            <td width="9%"><span><b>Announcement </b></span></td>
            <td width="23%"><label>
              <textarea row="5" cols="25" id="annoce" name="annoce">
        </textarea>
            </label></td>
            <td width="23%">&nbsp;</td>
            <td width="8%">&nbsp;</td>
          </tr>
            <tr>
            <td width="8%" height="48">&nbsp;</td>
            <td width="9%"><span><b>Refferance </b></span></td>
            <td width="23%"><label>
              <input name="number" type="number" id="number" placeholder="Refferance number">
            </label></td>
            <td width="23%">&nbsp;</td>
            <td width="8%">&nbsp;</td>
          </tr>
 <tr>
            <td width="8%" height="48">&nbsp;</td>
            <td width="9%"><span><b>Date </b></span></td>
            <td width="23%"><label>
              <input name="date" type="date" id="date">
            </label></td>
            <td width="23%">&nbsp;</td>
            <td width="8%">&nbsp;</td>
          </tr>
         
<tr>
            <td height="46">&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="btn" type="submit" id="btn" value="ADD">&emsp;
                
            </tr>

</table>
</form>
</body>
</html>
