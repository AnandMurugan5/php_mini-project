-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 25, 2019 at 10:24 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `annoce`
--

CREATE TABLE `annoce` (
  `sno` int(125) NOT NULL,
  `Annocement` text NOT NULL,
  `Refferace` int(10) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `annoce`
--

INSERT INTO `annoce` (`sno`, `Annocement`, `Refferace`, `date`) VALUES
(2, 'Software Engineer at ZOHO/for\r\nMCA,BE,B.TECH Fresher\r\n@Chennai\r\n', 33, '2020-01-03'),
(3, 'Graphics Designer @IBM\r\n', 123, '2019-12-05'),
(4, 'Hardware Experts and Networking\r\n@TCS', 15, '2019-12-24'),
(5, 'Assistant Professor for Department of Computer science and Applications @PMU Tanjore\r\nQualification: MCA,BE and B.Tech OR PG with B.ET   ', 54, '2019-12-30'),
(6, 'Game Designers @DigitalGame pvt(L) Bangulore', 534, '2019-12-27'),
(8, '        IBM compus', 36, '2019-12-25'),
(12, 'IBM internship for MCA fresher are Studend Batch 2020', 562, '2019-12-04');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `D_NO` int(125) NOT NULL,
  `Name` varchar(225) NOT NULL,
  `D_O_B` date NOT NULL,
  `department` varchar(225) NOT NULL,
  `class` text NOT NULL,
  `phone` int(10) NOT NULL,
  `email` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`D_NO`, `Name`, `D_O_B`, `department`, `class`, `phone`, `email`) VALUES
(0, '', '0000-00-00', '1', '1', 0, ''),
(33, 'Anand Victor', '1999-09-24', 'Computer Science and Application', '2PG', 12341231, 'anandmurugan2499@gmail.com'),
(54, 'Hari', '1998-12-06', 'Computer Application', '2PG', 12341233, 'hari1998@gmail.com'),
(123, 'Gnana Sekar', '1996-05-16', 'Bio-Tech', '3UG', 12341253, 'gnanaseker1996@gmail.com'),
(125, 'Julia', '2019-12-11', 'Software Engineering', '2PG', 32341253, 'csashok123@gmail.com'),
(534, 'Logi', '1998-12-09', 'Computer Application', '2PG', 12341232, 'logi1998@gmail.com'),
(12345, 'cj', '2019-12-25', '6', '1', 0, 'cj@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `annoce`
--
ALTER TABLE `annoce`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`D_NO`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
