
<html>

<head>
<title>sjcplacement
</title>

<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
	.db{
		margin: 0px;
		padding: 20px;
		background-color: white;
		border: 1px solid block;
	}
	 th{
		margin: 0px;
		padding: 0px;
		border: 1px solid #626262;
	}
</style>

</head><body>
<table width="100%" border="3" align="center" bordercolor="yellow">
<div class="menu">
 
 <div class="leftmenu">
 <h8>PLACEMENT&nbsp;CELL</h8>
 </div>
 </table> 
 <div class="rightmenu">
 <ul>
  <li><a href="liststud.php">Student List</a></li>
 <li><a href="annoce.php">Announcement</a></li>
  <li><a href="adminlogin.php">Logout</a></li>
 </ul>
 </div>
</div>
<div class="db" align="center">
<table border="1">
	<tbody>
		<th>D_NO</th>&nbsp;
		<th>Name</th>&nbsp;
		<th>D.O.B</th>&nbsp;
		<th>Deparment</th>&nbsp;
		<th>class</th>&nbsp;
		<th>Phone</th>&nbsp;
		<th>Email_Id</th>
		<?php
			$conn = mysqli_connect("localhost","root","","project");
			if ($conn-> connect_error) {
				die("Connnection failed:". $conn-> connect_error);
			}
			$sql ="SELECT * from student";
			$result = $conn-> query($sql);
			if ($result-> num_rows > 0) {
				
				while ($row = $result-> fetch_assoc()) {
					echo "<tr><td>". $row["D_NO"] ."</td><td>".$row["Name"]."</td><td>".$row["D_O_B"]."</td><td>".$row["department"]."</td><td>".$row["class"]."</td><td>".$row["phone"]."</td><td>".$row["email"]."</td></tr>";
				}
				echo "</table>";
			}
			else{

				echo "<br><br>0 result";
			}
			$conn-> close();
		?>
	</tbody>
</table>
</div>
</body>
</html>
