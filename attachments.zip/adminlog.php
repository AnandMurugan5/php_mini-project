
<!DOCTYPE html>
<html>
<head>
<title>admin
</title>

<link rel="stylesheet" type="text/css" href="style.css">

</head><body>
<table width="100%" border="3" align="center" bordercolor="yellow">
<div class="menu">
 
 <div class="leftmenu">
 <h8>PLACEMENT&nbsp;CELL</h8>
 </div>
 </table>
 <div class="rightmenu">
 <ul>
 <li><a href="liststud.php">Student List</a></li>
 <li><a href="annoce.php">Announcement</a></li>
  <li><a href="adminlogin.php">Logout</a></li>
   
 </ul>
 </div>
</div> 
 <p align="center">&nbsp;welcome to SJC placemnt cell </p>
 
</body>
</html>
