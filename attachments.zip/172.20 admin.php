

<html>
<head>
<title>admin
</title>

<link rel="stylesheet" type="text/css" href="style.css">

</head><body>
<table width="100%" border="3" align="center" bordercolor="yellow">
<div class="menu">
 
 <div class="leftmenu">
 <h8>PLACEMENT&nbsp;CELL</h8>
 </div>
 </table>
 <div class="rightmenu">
 <ul>
 <li><a href="intent.php">Home</a></li>
 <li><a href="adminlogin.php">Admin</a></li>
  <li><a href="studentlogin.php">Student</a></li>
   
 </ul>
 </div>
</div> 
 



  <form action="adminlog.php" method="post" name="form1">
 <center>
   <table width="100%" border="0" align="center">
   
              
          <tr>
            <td height="48">&nbsp;</td>
   
            <td colspan="2"><div align="center" ><b><font size="10"color="darkblue">Admin Login</font> </b></div></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td width="8%" height="48">&nbsp;</td>
            <td width="9%"><span><b>User Name </b></span></td>
            <td width="23%"><label>
              <input name="uname" type="text" id="uname">
            </label></td>
            <td width="23%">&nbsp;</td>
            <td width="8%">&nbsp;</td>
          </tr>
          <tr>
            <td height="49">&nbsp;</td>
            <td><span><b>Password</b></span></td>
            <td><input name="password" type="password" id="password"></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td height="46">&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="btn" type="submit" id="btn" value="Login">&emsp;
                <input name="btn2" type="reset" id="btn2" value="Reset"></td>
       
           
         
       
       </tr>
        </table>
		</center>
  </form>
 
</body>
</html>
