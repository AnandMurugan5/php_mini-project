<?php
	$con =  mysqli_connect('localhost','root','');
	if(!$con)
	{
		echo 'NOT Connected to Server';
	}
	if(mysqli_select_db($con,'project'))
	{
		echo 'Database Not Selected';
	}
	$sno = $_POST['sno'];
	$Annocement = $_POST['annoce'];
	$Refferace = $_POST['number'];
	$date = $_POST['date'];
	$sql = "INSERT INTO annoce values('$sno','$Annocement','$Refferace','$date')";
	
	if(!mysqli_query($con,$sql))
	{
		echo '<BR>Some values missing';
	}
	else
	{
		echo 'sucessfully completed';
	}
	header("refresh:2; url=annoce.php");
	?>
