<html>
<head>
<title>sjcplacement
</title>

<link rel="stylesheet" type="text/css" href="style.css">

</head><body>
<table width="100%" border="3" align="center" bordercolor="yellow">
<div class="menu">
 
 <div class="leftmenu">
 <h8 align="center">PLACEMENT&nbsp;CELL</h8>
 </div>
 </table> 
 <div class="rightmenu">
 <ul>
 <li><a href="intent.php">Home</a></li>
  <li><a href="studentlogin.php">Student</a></li>
  
 </ul>
 </div>
 <div class="db" align="center">
<table border="1px solid #626262">
	<tbody>
		<th>S_NO</th>&nbsp;
		<th>Annocement</th>&nbsp;
		<th>Refferance</th>&nbsp;
		<th>Posted Date</th>&nbsp;
		
		<?php
			$conn = mysqli_connect("localhost","root","","project");
			if ($conn-> connect_error) {
				die("Connnection failed:". $conn-> connect_error);
			}
			$sql ="SELECT * from annoce";
			$result = $conn-> query($sql);
			if ($result-> num_rows > 0) {
				
				while ($row = $result-> fetch_assoc()) {
					echo "<tr><td>". $row["sno"] ."</td><td>".$row["Annocement"]."</td><td>".$row["Refferace"]."</td><td>".$row["date"]."</td><rd>";
				}
				echo "</table>";
			}
			else{

				echo "<br><br>0 result";
			}
			$conn-> close();
		?>
	</tbody>
</table>
</div>
<form action="reg1.php">
    <div align="left" >
	<input type="Submit" name="Apply" id="btn1" value="Apply" align="left">
	</div>
</form>
</div> 
 </body>
</html>